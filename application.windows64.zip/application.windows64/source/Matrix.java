import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Matrix extends PApplet {

int cellSide;
int numCols, numRows, cellWidth, cellHeight;

final Alphabet alphabet = new Alphabet();
CellMatrix matrix;

final int GREEN = color(13,222,0);
final int RED = color(198,0,0);
final int BLUE = color(23, 45, 214);
final int YELLOW = color(198, 175, 0);
final int PURPLE = color(120, 26, 216);

int CURRENT_COLOR = GREEN;

public void mouseClicked(){

    exit();

}

public void keyPressed(){
    
    switch(key){
    
        case '1':
            CURRENT_COLOR = GREEN;
        break;
        case '2':
            CURRENT_COLOR = BLUE;
        break;
        case '3':
            CURRENT_COLOR = RED;
        break;
        case '4':
            CURRENT_COLOR = YELLOW;
        break;
        case '5':
            CURRENT_COLOR = PURPLE;
        break;
        
    }

}

public void setup(){
    
    cellSide = displayWidth/175;
    
    
    textSize(cellSide);
    frameRate(30);
    stroke(255);
    background(0);
    textAlign(CENTER, CENTER);

    cellWidth = cellHeight = cellSide;

    numCols = width / cellWidth;
    numRows = height / cellHeight;

    matrix = new CellMatrix(numCols, numRows);
    rotate(radians(90));

}

public void draw(){
    
    background(0);
    
    matrix.step();
    matrix.draw();
    
    if(random(1) < 0.30f)
        matrix.startRow();
    
}

public void putc(char c, int x, int y, int col){

    stroke(col);
    fill(col);
    text(c, x*cellWidth, (y+1)*cellHeight);
    
}
class Alphabet extends ArrayList<Character>{
    
    public Alphabet(){
    
        int[] charRanges = {33,33, 35,38, 48,57, 63,90, 97,122};
        
        for(int i = 0; i < charRanges.length; i += 2){
    
            for(int j = charRanges[i]; j <= charRanges[i+1]; j++){
            
                this.add((char)j);
            
            }
        
        }
        
    }

    public char getRandChar(){
        
        return get(PApplet.parseInt(random(0, alphabet.size())));
    
    }

}
class Cell{

    public boolean active;
    public int lifetime;
    public int cascadetime;
    public char c; 
    public int col;

}
final int DEFAULT_LIFETIME = 100;
final int DEFAULT_CASCADETIME = 1;

class CellMatrix{

    Cell[][] matrix;
    
    ArrayList<Tuple<Integer>> activeCells;
    ArrayList<Tuple<Integer>> cellsToRemoveFromActiveList;
    ArrayList<Tuple<Integer>> cellsToAddToActiveList;
    
    public CellMatrix(int x, int y){
    
        activeCells = new ArrayList();
        
        cellsToRemoveFromActiveList = new ArrayList();
        cellsToAddToActiveList = new ArrayList();
        
        matrix = new Cell[x][y];
        
        for(int i = 0; i < x; i++)
            for(int j = 0; j < y; j++)
                matrix[i][j] = new Cell();
    
    }
    
    public void startRow(){
    
        int r;
        
        do{
            
            r = PApplet.parseInt(random(0, numCols));
        
        }while(matrix[r][0].active);
        
        matrix[r][0].active = true;
        matrix[r][0].lifetime = DEFAULT_LIFETIME;
        //matrix[r][0].cascadetime = DEFAULT_CASCADETIME;
        matrix[r][0].cascadetime = PApplet.parseInt(random(1,3));
        matrix[r][0].c = alphabet.getRandChar();
        
        activeCells.add(new Tuple(r,0)); 
    
    }
    
    public void step(){
        
        for(Tuple<Integer> t : activeCells){
        
            Cell cell = matrix[t.first][t.second];
        
            // Delete the cell if the lifetime is up
            if(cell.lifetime <= 0){
                
                cell.active = false;
                cellsToRemoveFromActiveList.add(t);
                continue;
            
            }
        
            if(cell.cascadetime <= 0){
                
                if(t.second + 1 < matrix[0].length && !matrix[t.first][t.second+1].active){
                
                    Cell cellBelow = matrix[t.first][t.second+1];
                    
                    if(!cellBelow.active){
                    
                        cellsToAddToActiveList.add(new Tuple(t.first, t.second+1));
                        cellBelow.active = true;
                    
                        cellBelow.lifetime = DEFAULT_LIFETIME;
                        //cellBelow.cascadetime = DEFAULT_CASCADETIME;
                        cellBelow.cascadetime = PApplet.parseInt(random(1,3));
                        cellBelow.c = alphabet.getRandChar();
                    
                    }
                }
            }
        
            if(random(1) < 0.005f){
            
                cell.c = alphabet.getRandChar();
            
            }
        
            /*
            Color the cell here.
            */
            if(cell.lifetime >= DEFAULT_LIFETIME - DEFAULT_CASCADETIME)
                cell.col = color(255);
            else
                cell.col = color(red(CURRENT_COLOR), green(CURRENT_COLOR), blue(CURRENT_COLOR), map(cell.lifetime, 0, DEFAULT_LIFETIME, 0, 255));
            
        
            cell.lifetime--;
            cell.cascadetime--;
        
        }
    
        for(Tuple<Integer> t : cellsToRemoveFromActiveList){
        
            activeCells.remove(t);
        
        }
    
        for(Tuple<Integer> t : cellsToAddToActiveList){
        
            activeCells.add(t);
        
        }
    
        cellsToRemoveFromActiveList.clear();
        cellsToAddToActiveList.clear();
    
    }

    public void draw(){
    
        for(Tuple<Integer> t : activeCells){
        
            Cell cell = matrix[t.first][t.second];
            putc(cell.c, t.first, t.second, cell.col);
        
        }
    
    }

}

class Tuple<T>{

    public T first;
    public T second;
    
    public Tuple(T first, T second){
    
        this.first = first;
        this.second = second;
    
    }  

}
    public void settings() {  fullScreen(); }
    static public void main(String[] passedArgs) {
        String[] appletArgs = new String[] { "--present", "--window-color=#666666", "--hide-stop", "Matrix" };
        if (passedArgs != null) {
          PApplet.main(concat(appletArgs, passedArgs));
        } else {
          PApplet.main(appletArgs);
        }
    }
}
